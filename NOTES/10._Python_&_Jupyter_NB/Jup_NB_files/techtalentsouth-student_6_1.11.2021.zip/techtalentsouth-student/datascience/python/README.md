<!-- # QLX-I !-->
# Tech Talent South

- - -

## Data Science Fundamentals: Python

- - - 

[![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/enterlifeonline/techtalentsouth/blob/master/datascience/python/index.ipynb)
