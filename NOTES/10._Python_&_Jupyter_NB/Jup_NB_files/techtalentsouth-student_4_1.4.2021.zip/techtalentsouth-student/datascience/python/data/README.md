# 1918 Pandemic Influenza Mortality, Chicago USA

Point location and week of epidemic of 8,031 influenza and pneumonia deaths recorded during the 1918 Spanish flu pandemic within the city of Chicago and socio-demographic data (including population size, illiteracy, unemployment) of 496 census tracts within the City of Chicago. Data was collected from the 1920 national census and 1920 City of Chicago Department of Health annual report.

Datafile: points.csv | 258.92 KB
Datafile: tracts.csv | 355.35 KB

Taken from http://www.ufiddynamics.org/data
