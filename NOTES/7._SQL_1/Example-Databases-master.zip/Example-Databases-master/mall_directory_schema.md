# Mall Directory Schema

| PK   | id            | Integer |
| ---- | ------------- | ------- |
|      | store_name    | String  |
|      | mall_entrance | String  |
|      | mall_location | String  |
|      | category      | String  |

